import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:umrah_companion/providers/language_provider.dart';
import 'package:umrah_companion/providers/theme_provider.dart';
import 'package:umrah_companion/screens/home_screen.dart';
import 'package:umrah_companion/screens/splash_screen.dart';
import 'package:umrah_companion/utils/app_theme.dart';
import 'package:umrah_companion/utils/constants.dart';
import 'package:umrah_companion/utils/localization.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize services and load data
  // This would include loading content files, initializing databases, etc.
  
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LanguageProvider()),
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
      ],
      child: const UmrahCompanionApp(),
    ),
  );
}

class UmrahCompanionApp extends StatelessWidget {
  const UmrahCompanionApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final themeProvider = Provider.of<ThemeProvider>(context);
    
    return MaterialApp(
      title: 'Umrah Companion',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: themeProvider.themeMode,
      locale: languageProvider.locale,
      supportedLocales: const [
        Locale('en', ''), // English
        Locale('ar', ''), // Arabic
      ],
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const SplashScreen(),
      routes: {
        AppRoutes.home: (context) => const HomeScreen(),
        // Add other routes here
      },
    );
  }
}
