import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:umrah_companion/providers/language_provider.dart';
import 'package:umrah_companion/screens/education_screen.dart';
import 'package:umrah_companion/screens/home_screen.dart';
import 'package:umrah_companion/screens/multimedia_screen.dart';
import 'package:umrah_companion/screens/planner_screen.dart';
import 'package:umrah_companion/screens/rituals_screen.dart';
import 'package:umrah_companion/screens/settings_screen.dart';
import 'package:umrah_companion/screens/travel_kit_screen.dart';

class AppRouter {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/':
      case '/home':
        return MaterialPageRoute(builder: (_) => const HomeScreen());
      case '/education':
        return MaterialPageRoute(builder: (_) => const EducationScreen());
      case '/rituals':
        return MaterialPageRoute(builder: (_) => const RitualsScreen());
      case '/travel_kit':
        return MaterialPageRoute(builder: (_) => const TravelKitScreen());
      case '/planner':
        return MaterialPageRoute(builder: (_) => const PlannerScreen());
      case '/multimedia':
        return MaterialPageRoute(builder: (_) => const MultimediaScreen());
      case '/settings':
        return MaterialPageRoute(builder: (_) => const SettingsScreen());
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(
              child: Builder(
                builder: (context) {
                  final isArabic = Provider.of<LanguageProvider>(context).locale.languageCode == 'ar';
                  return Text(
                    isArabic ? 'الصفحة غير موجودة' : 'Page not found',
                    style: TextStyle(fontSize: 24),
                  );
                },
              ),
            ),
          ),
        );
    }
  }
}
