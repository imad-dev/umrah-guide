import 'package:flutter/material.dart';

class AppTheme {
  // Primary colors
  static const Color primaryGreen = Color(0xFF1B5E20);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color primaryGold = Color(0xFFFFD700);
  
  // Secondary colors
  static const Color secondaryGreen = Color(0xFF388E3C);
  static const Color secondaryGold = Color(0xFFFFC107);
  static const Color lightGreen = Color(0xFFE8F5E9);
  
  // Text colors
  static const Color textDark = Color(0xFF212121);
  static const Color textMedium = Color(0xFF757575);
  static const Color textLight = Color(0xFFBDBDBD);
  
  // Background colors
  static const Color backgroundLight = Color(0xFFF5F5F5);
  static const Color backgroundDark = Color(0xFF121212);
  
  // Error colors
  static const Color errorColor = Color(0xFFB00020);
  
  // Light theme
  static final ThemeData lightTheme = ThemeData(
    primaryColor: primaryGreen,
    colorScheme: ColorScheme.light(
      primary: primaryGreen,
      secondary: secondaryGold,
      background: backgroundLight,
      error: errorColor,
    ),
    scaffoldBackgroundColor: backgroundLight,
    appBarTheme: const AppBarTheme(
      backgroundColor: primaryGreen,
      foregroundColor: primaryWhite,
      elevation: 0,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primaryGreen,
        foregroundColor: primaryWhite,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: primaryGreen,
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: primaryGreen,
        side: const BorderSide(color: primaryGreen),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    ),
    cardTheme: CardTheme(
      color: primaryWhite,
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
    ),
    textTheme: const TextTheme(
      displayLarge: TextStyle(color: textDark),
      displayMedium: TextStyle(color: textDark),
      displaySmall: TextStyle(color: textDark),
      headlineLarge: TextStyle(color: textDark),
      headlineMedium: TextStyle(color: textDark),
      headlineSmall: TextStyle(color: textDark),
      titleLarge: TextStyle(color: textDark),
      titleMedium: TextStyle(color: textDark),
      titleSmall: TextStyle(color: textDark),
      bodyLarge: TextStyle(color: textDark),
      bodyMedium: TextStyle(color: textDark),
      bodySmall: TextStyle(color: textMedium),
      labelLarge: TextStyle(color: textDark),
      labelMedium: TextStyle(color: textDark),
      labelSmall: TextStyle(color: textMedium),
    ),
    iconTheme: const IconThemeData(
      color: primaryGreen,
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: primaryWhite,
      selectedItemColor: primaryGreen,
      unselectedItemColor: textMedium,
    ),
    tabBarTheme: const TabBarTheme(
      labelColor: primaryGreen,
      unselectedLabelColor: textMedium,
      indicator: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: primaryGreen,
            width: 2.0,
          ),
        ),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: textLight),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: primaryGreen),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: textLight),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: errorColor),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: errorColor),
      ),
      labelStyle: const TextStyle(color: textMedium),
      hintStyle: const TextStyle(color: textLight),
    ),
    dividerTheme: const DividerThemeData(
      color: textLight,
      thickness: 1,
      space: 1,
    ),
    checkboxTheme: CheckboxThemeData(
      fillColor: MaterialStateProperty.resolveWith<Color>((states) {
        if (states.contains(MaterialState.selected)) {
          return primaryGreen;
        }
        return textLight;
      }),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(4),
      ),
    ),
    radioTheme: RadioThemeData(
      fillColor: MaterialStateProperty.resolveWith<Color>((states) {
        if (states.contains(MaterialState.selected)) {
          return primaryGreen;
        }
        return textLight;
      }),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: MaterialStateProperty.resolveWith<Color>((states) {
        if (states.contains(MaterialState.selected)) {
          return primaryGreen;
        }
        return textLight;
      }),
      trackColor: MaterialStateProperty.resolveWith<Color>((states) {
        if (states.contains(MaterialState.selected)) {
          return primaryGreen.withOpacity(0.5);
        }
        return textLight.withOpacity(0.5);
      }),
    ),
    sliderTheme: SliderThemeData(
      activeTrackColor: primaryGreen,
      inactiveTrackColor: textLight,
      thumbColor: primaryGreen,
      overlayColor: primaryGreen.withOpacity(0.2),
      valueIndicatorColor: primaryGreen,
      valueIndicatorTextStyle: const TextStyle(color: primaryWhite),
    ),
    progressIndicatorTheme: const ProgressIndicatorThemeData(
      color: primaryGreen,
      linearTrackColor: lightGreen,
      circularTrackColor: lightGreen,
    ),
  );
  
  // Dark theme
  static final ThemeData darkTheme = ThemeData(
    primaryColor: primaryGreen,
    colorScheme: ColorScheme.dark(
      primary: primaryGreen,
      secondary: secondaryGold,
      background: backgroundDark,
      error: errorColor,
    ),
    scaffoldBackgroundColor: backgroundDark,
    appBarTheme: const AppBarTheme(
      backgroundColor: primaryGreen,
      foregroundColor: primaryWhite,
      elevation: 0,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primaryGreen,
        foregroundColor: primaryWhite,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: primaryGreen,
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: primaryGreen,
        side: const BorderSide(color: primaryGreen),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    ),
    cardTheme: CardTheme(
      color: backgroundDark.withOpacity(0.8),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
    ),
    textTheme: const TextTheme(
      displayLarge: TextStyle(color: primaryWhite),
      displayMedium: TextStyle(color: primaryWhite),
      displaySmall: TextStyle(color: primaryWhite),
      headlineLarge: TextStyle(color: primaryWhite),
      headlineMedium: TextStyle(color: primaryWhite),
      headlineSmall: TextStyle(color: primaryWhite),
      titleLarge: TextStyle(color: primaryWhite),
      titleMedium: TextStyle(color: primaryWhite),
      titleSmall: TextStyle(color: primaryWhite),
      bodyLarge: TextStyle(color: primaryWhite),
      bodyMedium: TextStyle(color: primaryWhite),
      bodySmall: TextStyle(color: textLight),
      labelLarge: TextStyle(color: primaryWhite),
      labelMedium: TextStyle(color: primaryWhite),
      labelSmall: TextStyle(color: textLight),
    ),
    iconTheme: const IconThemeData(
      color: primaryGreen,
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: backgroundDark,
      selectedItemColor: primaryGreen,
      unselectedItemColor: textLight,
    ),
    tabBarTheme: const TabBarTheme(
      labelColor: primaryGreen,
      unselectedLabelColor: textLight,
      indicator: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: primaryGreen,
            width: 2.0,
          ),
        ),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: textMedium),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: primaryGreen),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: textMedium),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: errorColor),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: errorColor),
      ),
      labelStyle: const TextStyle(color: textLight),
      hintStyle: const TextStyle(color: textMedium),
    ),
    dividerTheme: const DividerThemeData(
      color: textMedium,
      thickness: 1,
      space: 1,
    ),
    checkboxTheme: CheckboxThemeData(
      fillColor: MaterialStateProperty.resolveWith<Color>((states) {
        if (states.contains(MaterialState.selected)) {
          return primaryGreen;
        }
        return textMedium;
      }),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(4),
      ),
    ),
    radioTheme: RadioThemeData(
      fillColor: MaterialStateProperty.resolveWith<Color>((states) {
        if (states.contains(MaterialState.selected)) {
          return primaryGreen;
        }
        return textMedium;
      }),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: MaterialStateProperty.resolveWith<Color>((states) {
        if (states.contains(MaterialState.selected)) {
          return primaryGreen;
        }
        return textMedium;
      }),
      trackColor: MaterialStateProperty.resolveWith<Color>((states) {
        if (states.contains(MaterialState.selected)) {
          return primaryGreen.withOpacity(0.5);
        }
        return textMedium.withOpacity(0.5);
      }),
    ),
    sliderTheme: SliderThemeData(
      activeTrackColor: primaryGreen,
      inactiveTrackColor: textMedium,
      thumbColor: primaryGreen,
      overlayColor: primaryGreen.withOpacity(0.2),
      valueIndicatorColor: primaryGreen,
      valueIndicatorTextStyle: const TextStyle(color: primaryWhite),
    ),
    progressIndicatorTheme: const ProgressIndicatorThemeData(
      color: primaryGreen,
      linearTrackColor: secondaryGreen,
      circularTrackColor: secondaryGreen,
    ),
  );
}
