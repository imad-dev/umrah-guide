import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:umrah_companion/providers/language_provider.dart';
import 'package:umrah_companion/utils/app_theme.dart';

class MultimediaScreen extends StatefulWidget {
  const MultimediaScreen({Key? key}) : super(key: key);

  @override
  _MultimediaScreenState createState() => _MultimediaScreenState();
}

class _MultimediaScreenState extends State<MultimediaScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.locale.languageCode == 'ar';
    
    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? 'الوسائط المتعددة' : 'Multimedia'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          tabs: [
            Tab(
              icon: Icon(Icons.video_library),
              text: isArabic ? 'الفيديوهات' : 'Videos',
            ),
            Tab(
              icon: Icon(Icons.photo_library),
              text: isArabic ? 'الصور' : 'Photos',
            ),
            Tab(
              icon: Icon(Icons.headset),
              text: isArabic ? 'الصوتيات' : 'Audio',
            ),
          ],
        ),
      ),
      body: Directionality(
        textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
        child: TabBarView(
          controller: _tabController,
          children: [
            // Videos Tab
            _buildVideosTab(isArabic),
            
            // Photos Tab
            _buildPhotosTab(isArabic),
            
            // Audio Tab
            _buildAudioTab(isArabic),
          ],
        ),
      ),
    );
  }
  
  Widget _buildVideosTab(bool isArabic) {
    final videoCategories = [
      {
        'title_en': 'Umrah Rituals',
        'title_ar': 'مناسك العمرة',
        'videos': [
          {
            'title_en': 'Complete Umrah Guide',
            'title_ar': 'دليل العمرة الكامل',
            'duration': '15:30',
            'thumbnail': 'assets/images/videos/umrah_guide.jpg',
          },
          {
            'title_en': 'How to Perform Tawaf',
            'title_ar': 'كيفية أداء الطواف',
            'duration': '08:45',
            'thumbnail': 'assets/images/videos/tawaf.jpg',
          },
          {
            'title_en': 'How to Perform Sa\'i',
            'title_ar': 'كيفية أداء السعي',
            'duration': '07:20',
            'thumbnail': 'assets/images/videos/sai.jpg',
          },
          {
            'title_en': 'Ihram Guidelines',
            'title_ar': 'إرشادات الإحرام',
            'duration': '06:15',
            'thumbnail': 'assets/images/videos/ihram.jpg',
          },
        ],
      },
      {
        'title_en': 'Do\'s and Don\'ts',
        'title_ar': 'ما يجب وما لا يجب فعله',
        'videos': [
          {
            'title_en': 'Common Mistakes During Umrah',
            'title_ar': 'الأخطاء الشائعة أثناء العمرة',
            'duration': '10:20',
            'thumbnail': 'assets/images/videos/mistakes.jpg',
          },
          {
            'title_en': 'Etiquette in the Holy Mosques',
            'title_ar': 'آداب السلوك في المساجد المقدسة',
            'duration': '09:15',
            'thumbnail': 'assets/images/videos/etiquette.jpg',
          },
          {
            'title_en': 'What to Avoid During Ihram',
            'title_ar': 'ما يجب تجنبه أثناء الإحرام',
            'duration': '07:40',
            'thumbnail': 'assets/images/videos/avoid.jpg',
          },
        ],
      },
      {
        'title_en': 'Historical Sites',
        'title_ar': 'المواقع التاريخية',
        'videos': [
          {
            'title_en': 'History of the Kaaba',
            'title_ar': 'تاريخ الكعبة',
            'duration': '12:30',
            'thumbnail': 'assets/images/videos/kaaba_history.jpg',
          },
          {
            'title_en': 'Tour of Madinah',
            'title_ar': 'جولة في المدينة المنورة',
            'duration': '14:45',
            'thumbnail': 'assets/images/videos/madinah_tour.jpg',
          },
          {
            'title_en': 'Important Sites in Makkah',
            'title_ar': 'المواقع المهمة في مكة',
            'duration': '11:20',
            'thumbnail': 'assets/images/videos/makkah_sites.jpg',
          },
        ],
      },
    ];
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            isArabic ? 'مكتبة الفيديو' : 'Video Library',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            isArabic 
                ? 'شاهد مقاطع فيديو تعليمية وإرشادية عن العمرة'
                : 'Watch educational and instructional videos about Umrah',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 24),
          
          // Featured video
          Card(
            elevation: 3,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Video thumbnail with play button
                Stack(
                  alignment: Alignment.center,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
                      child: Container(
                        height: 200,
                        width: double.infinity,
                        color: Colors.grey[300],
                        child: Center(
                          child: Icon(
                            Icons.image,
                            size: 80,
                            color: Colors.grey[500],
                          ),
                        ),
                      ),
                    ),
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        color: AppTheme.primaryGreen.withOpacity(0.8),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        Icons.play_arrow,
                        color: Colors.white,
                        size: 40,
                      ),
                    ),
                  ],
                ),
                
                // Video info
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: AppTheme.primaryGreen,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              isArabic ? 'مميز' : 'FEATURED',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SizedBox(width: 8),
                          Text(
                            '20:15',
                            style: TextStyle(
                              color: Colors.grey[600],
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                      Text(
                        isArabic ? 'الدليل الشامل للعمرة: خطوة بخطوة' : 'Comprehensive Umrah Guide: Step by Step',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        isArabic 
                            ? 'دليل مفصل يشرح جميع خطوات العمرة من البداية إلى النهاية مع نصائح عملية'
                            : 'A detailed guide explaining all steps of Umrah from start to finish with practical tips',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          
          // Video categories
          ...videoCategories.map((category) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 24),
                Text(
                  isArabic ? category['title_ar'] as String : category['title_en'] as String,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 16),
                
                // Horizontal video list
                Container(
                  height: 180,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: (category['videos'] as List).length,
                    itemBuilder: (context, index) {
                      final video = (category['videos'] as List)[index];
                      
                      return Container(
                        width: 220,
                        margin: EdgeInsets.only(right: 16),
                        child: Card(
                          elevation: 2,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Video thumbnail
                              Stack(
                                alignment: Alignment.center,
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
                                    child: Container(
                                      height: 100,
                                      width: double.infinity,
                                      color: Colors.grey[300],
                                      child: Center(
                                        child: Icon(
                                          Icons.image,
                                          size: 40,
                                          color: Colors.grey[500],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    width: 40,
                                    height: 40,
                                    decoration: BoxDecoration(
                                      color: AppTheme.primaryGreen.withOpacity(0.8),
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(
                                      Icons.play_arrow,
                                      color: Colors.white,
                                      size: 24,
                                    ),
                                  ),
                                  Positioned(
                                    bottom: 8,
                                    right: 8,
                                    child: Container(
                                      padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: Colors.black.withOpacity(0.7),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                      child: Text(
                                        video['duration'] as String,
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              
                              // Video info
                              Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text(
                                  isArabic ? video['title_ar'] as String : video['title_en'] as String,
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          }).toList(),
          
          SizedBox(height: 24),
          
          // Offline availability indicator
          Container(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.green),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.check_circle, color: Colors.green, size: 16),
                SizedBox(width: 8),
                Text(
                  isArabic ? 'جميع مقاطع الفيديو متاحة للمشاهدة بدون إنترنت' : 'All videos available for offline viewing',
                  style: TextStyle(
                    color: Colors.green,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildPhotosTab(bool isArabic) {
    final photoCategories = [
      {
        'title_en': 'Holy Sites',
        'title_ar': 'المواقع المقدسة',
        'photos': [
          'assets/images/photos/kaaba.jpg',
          'assets/images/photos/masjid_haram.jpg',
          'assets/images/photos/masjid_nabawi.jpg',
          'assets/images/photos/black_stone.jpg',
          'assets/images/photos/maqam_ibrahim.jpg',
          'assets/images/photos/safa_marwa.jpg',
        ],
      },
      {
        'title_en': 'Makkah',
        'title_ar': 'مكة المكرمة',
        'photos': [
          'assets/images/photos/makkah_1.jpg',
          'assets/images/photos/makkah_2.jpg',
          'assets/images/photos/makkah_3.jpg',
          'assets/images/photos/makkah_4.jpg',
          'assets/images/photos/makkah_5.jpg',
        ],
      },
      {
        'title_en': 'Madinah',
        'title_ar': 'المدينة المنورة',
        'photos': [
          'assets/images/photos/madinah_1.jpg',
          'assets/images/photos/madinah_2.jpg',
          'assets/images/photos/madinah_3.jpg',
          'assets/images/photos/madinah_4.jpg',
        ],
      },
      {
        'title_en': 'Historical Sites',
        'title_ar': 'المواقع التاريخية',
        'photos': [
          'assets/images/photos/historical_1.jpg',
          'assets/images/photos/historical_2.jpg',
          'assets/images/photos/historical_3.jpg',
          'assets/images/photos/historical_4.jpg',
          'assets/images/photos/historical_5.jpg',
        ],
      },
    ];
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            isArabic ? 'معرض الصور' : 'Photo Gallery',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            isArabic 
                ? 'استكشف صوراً حقيقية من مكة والمدينة والمواقع المقدسة'
                : 'Explore real photos from Makkah, Madinah, and holy sites',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 24),
          
          // Featured photo
          Card(
            elevation: 3,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Photo
                ClipRRect(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
                  child: Container(
                    height: 200,
                    width: double.infinity,
                    color: Colors.grey[300],
                    child: Center(
                      child: Icon(
                        Icons.image,
                        size: 80,
                        color: Colors.grey[500],
                      ),
                    ),
                  ),
                ),
                
                // Photo info
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryGreen,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          isArabic ? 'صورة اليوم' : 'PHOTO OF THE DAY',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        isArabic ? 'الكعبة المشرفة عند الفجر' : 'The Holy Kaaba at Dawn',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        isArabic 
                            ? 'منظر مهيب للكعبة المشرفة في المسجد الحرام عند شروق الشمس'
                            : 'A majestic view of the Holy Kaaba in Masjid al-Haram at sunrise',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          
          // Photo categories
          ...photoCategories.map((category) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 24),
                Text(
                  isArabic ? category['title_ar'] as String : category['title_en'] as String,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 16),
                
                // Grid of photos
                GridView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                  ),
                  itemCount: (category['photos'] as List).length,
                  itemBuilder: (context, index) {
                    return Card(
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: InkWell(
                        onTap: () {
                          // View photo in full screen
                        },
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          color: Colors.grey[300],
                          child: Center(
                            child: Icon(
                              Icons.image,
                              size: 30,
                              color: Colors.grey[500],
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ],
            );
          }).toList(),
          
          SizedBox(height: 24),
          
          // Offline availability indicator
          Container(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.green),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.check_circle, color: Colors.green, size: 16),
                SizedBox(width: 8),
                Text(
                  isArabic ? 'جميع الصور متاحة للعرض بدون إنترنت' : 'All photos available for offline viewing',
                  style: TextStyle(
                    color: Colors.green,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildAudioTab(bool isArabic) {
    final audioCategories = [
      {
        'title_en': 'Duas for Umrah',
        'title_ar': 'أدعية العمرة',
        'audios': [
          {
            'title_en': 'Talbiyah',
            'title_ar': 'التلبية',
            'duration': '01:20',
          },
          {
            'title_en': 'Dua for Entering Masjid al-Haram',
            'title_ar': 'دعاء دخول المسجد الحرام',
            'duration': '00:45',
          },
          {
            'title_en': 'Duas for Tawaf',
            'title_ar': 'أدعية الطواف',
            'duration': '05:30',
          },
          {
            'title_en': 'Duas for Sa\'i',
            'title_ar': 'أدعية السعي',
            'duration': '04:15',
          },
          {
            'title_en': 'Dua after Completing Umrah',
            'title_ar': 'دعاء بعد إتمام العمرة',
            'duration': '01:50',
          },
        ],
      },
      {
        'title_en': 'Recitations',
        'title_ar': 'تلاوات',
        'audios': [
          {
            'title_en': 'Surah Al-Fatiha',
            'title_ar': 'سورة الفاتحة',
            'duration': '00:50',
          },
          {
            'title_en': 'Surah Al-Baqarah (Selected Verses)',
            'title_ar': 'سورة البقرة (آيات مختارة)',
            'duration': '03:20',
          },
          {
            'title_en': 'Surah Al-Imran (Selected Verses)',
            'title_ar': 'سورة آل عمران (آيات مختارة)',
            'duration': '02:45',
          },
          {
            'title_en': 'Ayatul Kursi',
            'title_ar': 'آية الكرسي',
            'duration': '01:10',
          },
        ],
      },
      {
        'title_en': 'Guided Meditations',
        'title_ar': 'تأملات موجهة',
        'audios': [
          {
            'title_en': 'Spiritual Reflection',
            'title_ar': 'تأمل روحي',
            'duration': '10:15',
          },
          {
            'title_en': 'Mindfulness During Tawaf',
            'title_ar': 'اليقظة الذهنية أثناء الطواف',
            'duration': '08:30',
          },
          {
            'title_en': 'Connecting with Allah',
            'title_ar': 'التواصل مع الله',
            'duration': '12:20',
          },
        ],
      },
    ];
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            isArabic ? 'مكتبة الصوتيات' : 'Audio Library',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            isArabic 
                ? 'استمع إلى الأدعية والتلاوات والإرشادات الصوتية'
                : 'Listen to duas, recitations, and audio guidance',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 24),
          
          // Featured audio player
          Card(
            elevation: 3,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryGreen,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          isArabic ? 'مميز' : 'FEATURED',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 12),
                  Text(
                    isArabic ? 'دليل صوتي كامل للعمرة' : 'Complete Audio Guide for Umrah',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    isArabic 
                        ? 'إرشادات صوتية خطوة بخطوة لجميع مناسك العمرة'
                        : 'Step-by-step audio guidance for all Umrah rituals',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                  SizedBox(height: 16),
                  
                  // Audio player controls
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        icon: Icon(Icons.replay_10),
                        onPressed: () {},
                      ),
                      IconButton(
                        icon: Icon(Icons.play_circle_filled),
                        iconSize: 50,
                        color: AppTheme.primaryGreen,
                        onPressed: () {},
                      ),
                      IconButton(
                        icon: Icon(Icons.forward_10),
                        onPressed: () {},
                      ),
                    ],
                  ),
                  
                  // Progress bar
                  Slider(
                    value: 0.3,
                    onChanged: (value) {},
                    activeColor: AppTheme.primaryGreen,
                    inactiveColor: Colors.grey[300],
                  ),
                  
                  // Time indicators
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '05:30',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[600],
                        ),
                      ),
                      Text(
                        '18:45',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          
          // Audio categories
          ...audioCategories.map((category) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 24),
                Text(
                  isArabic ? category['title_ar'] as String : category['title_en'] as String,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 16),
                
                // Audio list
                Card(
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ListView.separated(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: (category['audios'] as List).length,
                    separatorBuilder: (context, index) => Divider(height: 1),
                    itemBuilder: (context, index) {
                      final audio = (category['audios'] as List)[index];
                      
                      return ListTile(
                        leading: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: AppTheme.primaryGreen.withOpacity(0.1),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.music_note,
                            color: AppTheme.primaryGreen,
                          ),
                        ),
                        title: Text(
                          isArabic ? audio['title_ar'] as String : audio['title_en'] as String,
                        ),
                        subtitle: Text(
                          audio['duration'] as String,
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[600],
                          ),
                        ),
                        trailing: IconButton(
                          icon: Icon(Icons.play_arrow),
                          onPressed: () {
                            // Play audio
                          },
                        ),
                        onTap: () {
                          // View audio details
                        },
                      );
                    },
                  ),
                ),
              ],
            );
          }).toList(),
          
          SizedBox(height: 24),
          
          // Offline availability indicator
          Container(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.green),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.check_circle, color: Colors.green, size: 16),
                SizedBox(width: 8),
                Text(
                  isArabic ? 'جميع الملفات الصوتية متاحة للاستماع بدون إنترنت' : 'All audio files available for offline listening',
                  style: TextStyle(
                    color: Colors.green,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
