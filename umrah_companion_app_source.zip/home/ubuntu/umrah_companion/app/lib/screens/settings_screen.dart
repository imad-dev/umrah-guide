import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:umrah_companion/providers/language_provider.dart';
import 'package:umrah_companion/utils/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notificationsEnabled = true;
  bool _darkModeEnabled = false;
  bool _locationEnabled = true;
  bool _autoPlayAudio = true;
  String _fontSize = 'Medium';
  
  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.locale.languageCode == 'ar';
    
    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? 'الإعدادات' : 'Settings'),
      ),
      body: Directionality(
        textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Language section
              _buildSectionHeader(isArabic ? 'اللغة' : 'Language', Icons.language),
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      RadioListTile<String>(
                        title: Text('English'),
                        value: 'en',
                        groupValue: languageProvider.locale.languageCode,
                        onChanged: (value) {
                          if (value != null) {
                            languageProvider.setLocale(Locale(value, ''));
                          }
                        },
                        activeColor: AppTheme.primaryGreen,
                      ),
                      RadioListTile<String>(
                        title: Text('العربية'),
                        value: 'ar',
                        groupValue: languageProvider.locale.languageCode,
                        onChanged: (value) {
                          if (value != null) {
                            languageProvider.setLocale(Locale(value, ''));
                          }
                        },
                        activeColor: AppTheme.primaryGreen,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 24),
              
              // Appearance section
              _buildSectionHeader(isArabic ? 'المظهر' : 'Appearance', Icons.palette),
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    SwitchListTile(
                      title: Text(isArabic ? 'الوضع الداكن' : 'Dark Mode'),
                      subtitle: Text(
                        isArabic 
                            ? 'تفعيل المظهر الداكن للتطبيق'
                            : 'Enable dark appearance for the app',
                      ),
                      value: _darkModeEnabled,
                      activeColor: AppTheme.primaryGreen,
                      onChanged: (bool value) {
                        setState(() {
                          _darkModeEnabled = value;
                        });
                      },
                    ),
                    Divider(),
                    ListTile(
                      title: Text(isArabic ? 'حجم الخط' : 'Font Size'),
                      subtitle: Text(
                        isArabic 
                            ? 'ضبط حجم النص في التطبيق'
                            : 'Adjust text size throughout the app',
                      ),
                      trailing: DropdownButton<String>(
                        value: _fontSize,
                        onChanged: (String? newValue) {
                          if (newValue != null) {
                            setState(() {
                              _fontSize = newValue;
                            });
                          }
                        },
                        items: <String>['Small', 'Medium', 'Large', 'Extra Large']
                            .map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(
                              isArabic 
                                  ? value == 'Small' ? 'صغير' 
                                    : value == 'Medium' ? 'متوسط'
                                    : value == 'Large' ? 'كبير'
                                    : 'كبير جداً'
                                  : value,
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 24),
              
              // Notifications section
              _buildSectionHeader(isArabic ? 'الإشعارات' : 'Notifications', Icons.notifications),
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    SwitchListTile(
                      title: Text(isArabic ? 'الإشعارات' : 'Notifications'),
                      subtitle: Text(
                        isArabic 
                            ? 'تلقي إشعارات للتذكيرات والتحديثات'
                            : 'Receive notifications for reminders and updates',
                      ),
                      value: _notificationsEnabled,
                      activeColor: AppTheme.primaryGreen,
                      onChanged: (bool value) {
                        setState(() {
                          _notificationsEnabled = value;
                        });
                      },
                    ),
                    Divider(),
                    SwitchListTile(
                      title: Text(isArabic ? 'تنبيهات أوقات الصلاة' : 'Prayer Time Alerts'),
                      subtitle: Text(
                        isArabic 
                            ? 'تلقي إشعارات قبل كل وقت صلاة'
                            : 'Receive notifications before each prayer time',
                      ),
                      value: _notificationsEnabled,
                      activeColor: AppTheme.primaryGreen,
                      onChanged: _notificationsEnabled ? (bool value) {
                        // Toggle prayer alerts
                      } : null,
                    ),
                  ],
                ),
              ),
              SizedBox(height: 24),
              
              // Privacy section
              _buildSectionHeader(isArabic ? 'الخصوصية والأذونات' : 'Privacy & Permissions', Icons.security),
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    SwitchListTile(
                      title: Text(isArabic ? 'خدمات الموقع' : 'Location Services'),
                      subtitle: Text(
                        isArabic 
                            ? 'السماح للتطبيق باستخدام موقعك لتحديد اتجاه القبلة وأوقات الصلاة'
                            : 'Allow app to use your location for Qibla direction and prayer times',
                      ),
                      value: _locationEnabled,
                      activeColor: AppTheme.primaryGreen,
                      onChanged: (bool value) {
                        setState(() {
                          _locationEnabled = value;
                        });
                      },
                    ),
                  ],
                ),
              ),
              SizedBox(height: 24),
              
              // Media section
              _buildSectionHeader(isArabic ? 'الوسائط' : 'Media', Icons.headset),
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    SwitchListTile(
                      title: Text(isArabic ? 'تشغيل الصوت تلقائياً' : 'Auto-play Audio'),
                      subtitle: Text(
                        isArabic 
                            ? 'تشغيل الأدعية والإرشادات الصوتية تلقائياً'
                            : 'Automatically play duas and audio guidance',
                      ),
                      value: _autoPlayAudio,
                      activeColor: AppTheme.primaryGreen,
                      onChanged: (bool value) {
                        setState(() {
                          _autoPlayAudio = value;
                        });
                      },
                    ),
                  ],
                ),
              ),
              SizedBox(height: 24),
              
              // Data management section
              _buildSectionHeader(isArabic ? 'إدارة البيانات' : 'Data Management', Icons.storage),
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    ListTile(
                      title: Text(isArabic ? 'تنزيل المحتوى للاستخدام بدون إنترنت' : 'Download Content for Offline Use'),
                      subtitle: Text(
                        isArabic 
                            ? 'إدارة المحتوى المحلي للاستخدام بدون إنترنت'
                            : 'Manage local content for offline usage',
                      ),
                      trailing: Icon(Icons.arrow_forward_ios, size: 16),
                      onTap: () {
                        // Navigate to offline content management
                      },
                    ),
                    Divider(),
                    ListTile(
                      title: Text(isArabic ? 'مسح ذاكرة التخزين المؤقت' : 'Clear Cache'),
                      subtitle: Text(
                        isArabic 
                            ? 'مسح البيانات المؤقتة لتوفير مساحة التخزين'
                            : 'Clear temporary data to free up storage',
                      ),
                      trailing: TextButton(
                        child: Text(
                          isArabic ? 'مسح' : 'CLEAR',
                          style: TextStyle(
                            color: AppTheme.primaryGreen,
                          ),
                        ),
                        onPressed: () {
                          // Clear cache
                        },
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 24),
              
              // About section
              _buildSectionHeader(isArabic ? 'حول التطبيق' : 'About', Icons.info),
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    ListTile(
                      title: Text(isArabic ? 'إصدار التطبيق' : 'App Version'),
                      subtitle: Text('1.0.0'),
                    ),
                    Divider(),
                    ListTile(
                      title: Text(isArabic ? 'سياسة الخصوصية' : 'Privacy Policy'),
                      trailing: Icon(Icons.arrow_forward_ios, size: 16),
                      onTap: () {
                        // View privacy policy
                      },
                    ),
                    Divider(),
                    ListTile(
                      title: Text(isArabic ? 'شروط الاستخدام' : 'Terms of Use'),
                      trailing: Icon(Icons.arrow_forward_ios, size: 16),
                      onTap: () {
                        // View terms of use
                      },
                    ),
                    Divider(),
                    ListTile(
                      title: Text(isArabic ? 'تقديم ملاحظات' : 'Send Feedback'),
                      trailing: Icon(Icons.arrow_forward_ios, size: 16),
                      onTap: () {
                        // Send feedback
                      },
                    ),
                  ],
                ),
              ),
              SizedBox(height: 24),
              
              // Accessibility section
              _buildSectionHeader(isArabic ? 'إمكانية الوصول' : 'Accessibility', Icons.accessibility),
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    SwitchListTile(
                      title: Text(isArabic ? 'قارئ الشاشة' : 'Screen Reader Support'),
                      subtitle: Text(
                        isArabic 
                            ? 'تحسين التوافق مع قارئات الشاشة'
                            : 'Enhance compatibility with screen readers',
                      ),
                      value: true,
                      activeColor: AppTheme.primaryGreen,
                      onChanged: (bool value) {
                        // Toggle screen reader support
                      },
                    ),
                    Divider(),
                    SwitchListTile(
                      title: Text(isArabic ? 'تباين عالي' : 'High Contrast'),
                      subtitle: Text(
                        isArabic 
                            ? 'زيادة التباين لتحسين الرؤية'
                            : 'Increase contrast for better visibility',
                      ),
                      value: false,
                      activeColor: AppTheme.primaryGreen,
                      onChanged: (bool value) {
                        // Toggle high contrast
                      },
                    ),
                  ],
                ),
              ),
              SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildSectionHeader(String title, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        children: [
          Icon(
            icon,
            color: AppTheme.primaryGreen,
            size: 20,
          ),
          SizedBox(width: 8),
          Text(
            title,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
